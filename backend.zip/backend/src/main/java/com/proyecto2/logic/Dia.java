/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.proyecto2.logic;

/**
 *
 * @author ESCINF
 */
public class Dia {
    
    boolean checked = false;
    String desde;
    String hasta;

    public Dia(String desde, String hasta) {
        this.desde = desde;
        this.hasta = hasta;
    }
    
}
